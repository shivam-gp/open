import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './new-complaint/registration.component';
import { SideNaveComponent } from './side-nave/side-nave.component';

const routes: Routes = [
  {
    path : "home",
    component : HomeComponent
  },
  {
    path : "register",
    component : RegistrationComponent
  },
  {
    path: "side-nav",
    component : SideNaveComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
